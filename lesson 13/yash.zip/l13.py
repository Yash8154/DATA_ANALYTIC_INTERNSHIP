# -*- coding: utf-8 -*-
"""
Created on Fri Jul  8 16:55:56 2022

@author: Mehta Yash
"""

#case 01
#Kerala Results

from selenium import webdriver

from time import sleep

url = "http://keralaresults.nic.in/sslc2019duj946/swr_sslc.htm"




browser = webdriver.Chrome(executable_path = "C://Users//Mehta Yash//Chromedriver.exe")

browser.get(url)

sleep(2)

school_code = browser.find_element("name","treg")

school_code.send_keys('2000')

sleep(2)


get_school_result = browser.find_element('//html//body//form//table//tbody//tr[2]//td//table//tbody//tr[3]//td[3]//input[1]')

get_school_result.click()


html_page = browser.page_source


from bs4 import BeautifulSoup as BS


soup = BS(html_page)


browser.quit()
